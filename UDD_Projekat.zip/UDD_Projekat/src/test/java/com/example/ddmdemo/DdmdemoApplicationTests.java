package com.example.ddmdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DdmdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
