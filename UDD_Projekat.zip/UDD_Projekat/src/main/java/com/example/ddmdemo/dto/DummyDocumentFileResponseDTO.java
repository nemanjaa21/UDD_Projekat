package com.example.ddmdemo.dto;

public record DummyDocumentFileResponseDTO(String serverFilename) {
}
