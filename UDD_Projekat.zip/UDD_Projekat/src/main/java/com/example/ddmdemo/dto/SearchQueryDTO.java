package com.example.ddmdemo.dto;

import java.util.List;

public record SearchQueryDTO(List<String> keywords) {
}
