# UDD-materijali
Lab materials for Digital Documents Management (UDD) course on Faculty of Technical Sciences, Novi Sad.

## ICU Tokenizer installation
- `sudo docker exec -it ddmdemo-elasticsearch /bin/bash`
- `elasticsearch-plugin install analysis-icu`
- restart elasticsearch
